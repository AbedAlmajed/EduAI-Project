<!DOCTYPE html>
<html lang="en" dir="rtl">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="Webmin - Bootstrap 4 & Angular 5 Admin Dashboard Template" />
    <meta name="author" content="potenzaglobalsolutions.com" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title> EduAi </title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico" />

    <!-- Font -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Poppins:200,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900">

    <!-- css -->
    <link href="<?php echo e(URL::asset('assets/css/rtl.css')); ?>" rel="stylesheet">

</head>

<body>
    <div class="wrapper">
        <section class="height-100vh d-flex align-items-center page-section-ptb login" style="background-image: url('<?php echo e(asset('assets/images/sativa.png')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-8">
                        <div class="card border-0 rounded-lg">
                            <div class="card-body p-5">
                                <h3 class="text-center mb-4" style="font-family: 'Cairo', sans-serif;">حدد طريقة الدخول</h3>
                                <div class="row justify-content-center">
                                    <div class="col-lg-4 col-md-4 mb-4">
                                        <a  title="طالب" href="<?php echo e(route('login.show','student')); ?>">
                                            <img class="img-fluid" alt="طالب" src="<?php echo e(URL::asset('assets/images/student.png')); ?>">
                                            <div class="text-center mt-2">طالب</div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4 col-md-4 mb-4">
                                        <a  title="معلم" href="<?php echo e(route('login.show','teacher')); ?>">
                                            <img class="img-fluid" alt="معلم" src="<?php echo e(URL::asset('assets/images/teacher.png')); ?>">
                                            <div class="text-center mt-2">معلم</div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4 col-md-4 mb-4">
                                        <a  title="ادمن" href="<?php echo e(route('login.show','admin')); ?>">
                                            <img class="img-fluid" alt="ادمن" src="<?php echo e(URL::asset('assets/images/admin.png')); ?>">
                                            <div class="text-center mt-2">ادمن</div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    
    <!-- jquery -->
    <script src="<?php echo e(URL::asset('assets/js/jquery-3.3.1.min.js')); ?>"></script>
    <!-- plugins-jquery -->
    <script src="<?php echo e(URL::asset('assets/js/plugins-jquery.js')); ?>"></script>
    <!-- plugin_path -->
    <script>
        var plugin_path = 'js/';

    </script>


    <!-- toastr -->
    <?php echo $__env->yieldContent('js'); ?>
    <!-- custom -->
    <script src="<?php echo e(URL::asset('assets/js/custom.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\user\Desktop\mohannad\school-management-system-update_profile_in_dashboard_parent\school-management-system-update_profile_in_dashboard_parent\resources\views/auth/selection.blade.php ENDPATH**/ ?>