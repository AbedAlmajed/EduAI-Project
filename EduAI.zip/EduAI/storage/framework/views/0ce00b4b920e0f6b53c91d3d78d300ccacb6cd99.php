<?php $__env->startSection('css'); ?>
<style>
    .button {
        font-size: 0.4rem;
    }

    @media (min-width: 992px) {
        .button {
            font-size: 1rem;
        }
    }
</style>


<?php $__env->startSection('title'); ?>
<?php echo e(trans('admin_courseList.Course-List')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('admin_courseList.Course-List')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <table id="datatable" class="table table-hover table-sm table-bordered p-0" data-page-length="50" style="text-align: center">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(trans('admin_courseList.Course Name')); ?></th>
                            <th><?php echo e(trans('admin_courseList.Department(s)')); ?></th>
                            <th><?php echo e(trans('admin_courseList.Process')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $Courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php $i++; ?>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($Course->title); ?></td>
                            <td>
                                <?php $__currentLoopData = $Course->Department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($department->Name); ?> <?php if(!$loop->last): ?>, <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <!-- Delete button -->
                                <button  type="button" class="button-trash " data-toggle="modal" data-target="#delete_Course<?php echo e($Course->id); ?>">
                                    <i class="fas fa-trash"></i>
                                </button>

                                <div class="modal fade" id="delete_Course<?php echo e($Course->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <form action="<?php echo e(route('courses.delete', $Course->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(trans('admin_courseList.DeleteCourse')); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><?php echo e(trans('admin_courseList.title')); ?></p>
                                                    <input type="hidden" name="id" value="<?php echo e($Course->id); ?>">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(trans('admin_courseList.Cancel')); ?></button>
                                                    <button type="submit" class="btn btn-danger"><?php echo e(trans('admin_courseList.Delete')); ?></button>
                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                                <!-- Publish/Unpublish button -->
                                <form style="display: inline-block;" action="/course/toggle-publish/<?php echo e($Course->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <button style="display: inline-block;" type="submit" class=" <?php echo e($Course->published == 'Active' ? 'button ' : 'button-trash'); ?>">
                                        <?php echo $Course->published == 'Active' ? ' Published ' : ' Unpublished '; ?>

                                    </button>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\new mohanned\pro2 new new\school-management-system-update_profile_in_dashboard_parent\resources\views/course-list.blade.php ENDPATH**/ ?>