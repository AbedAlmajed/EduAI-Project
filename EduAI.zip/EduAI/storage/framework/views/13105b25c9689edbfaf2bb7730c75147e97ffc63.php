<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(trans('teacher_courses.Edit')); ?> <?php echo e($item->name); ?>-<?php echo e(trans('teacher_courses.Post')); ?> </title>

    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <!-- Summernote CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-bs4.min.css" rel="stylesheet">
</head>

<body>
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="text-center mb-4">
                    <h1><?php echo e(trans('teacher_courses.Edit2')); ?> <?php echo e($item->name); ?>-<?php echo e(trans('teacher_courses.Post')); ?></h1>
                </div>

                <form action="/update/<?php echo e($post->id); ?>/<?php echo e($course_id); ?>/<?php echo e($item_id); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <!-- Title Input -->
                    <div class="form-group">
                        <label for="title"><?php echo e(trans('teacher_courses.Title')); ?></label>
                        <input type="text" id="title" name="title" class="form-control" value="<?php echo e($post->title); ?>" required>
                    </div>

                    <!-- Description Textarea -->
                    <div class="form-group">
                        <label for="description"><?php echo e(trans('teacher_courses.Description')); ?></label>
                        <textarea id="description" name="description" class="form-control summernote" required><?php echo e($post->description); ?></textarea>
                    </div>

                    <!-- Sections Dropdown -->
                    <div class="form-group">
                        <label for="section_id"><?php echo e(trans('teacher_courses.Sections')); ?></label>
                        <select id="section_id" name="section_id" class="form-control" required>
                            <option value="" disabled selected><?php echo e(trans('teacher_courses.Choose from the list')); ?>...</option>
                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($section->course_id == $course_id): ?>
                                    <option value="<?php echo e($section->id); ?>" <?php echo e($item->section_id == $section->id ? 'selected' : ''); ?>>
                                        <?php echo e($section->name); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['section_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-success btn-lg"><?php echo e(trans('teacher_courses.Edit')); ?></button>
                </form>

                <!-- Cancel Button -->
                <form action="<?php echo e(route('lesson.editable', $course_id)); ?>" method="GET" class="mt-3">
                    <button type="submit" class="btn btn-secondary btn-lg"><?php echo e(trans('teacher_courses.Cancel')); ?></button>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

    <!-- Summernote JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-bs4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#description').summernote({
                placeholder: 'Enter your description...',
                height: 300
            });
        });
    </script>
</body>

</html>
<?php /**PATH C:\Users\user\Desktop\new mohanned\New Version\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/WYSIWYG/edit.blade.php ENDPATH**/ ?>