<?php $__env->startSection('css'); ?>
<style>
.progress-bar {
    transition: width 100s ease-in-out; /* Change the duration (1s) and the easing function (ease-in-out) as needed */
}


/* ..... */


.chart {
    background: rgba(165, 120, 120, 0.1);
    justify-content: flex-start;
    border-radius: 100px;
    align-items: center;
    position: relative;
    padding: 0 5px;
    display: flex;
    height: 40px;
    width: 200px;
}
    .chart span {
        /* You can modify the value below to change the distance between the percentage number and the bar */
        margin-left: 5px;
        color: #d12424;
        font-weight: bolder;
    }

.bar {
    box-shadow: 0 10px 40px -10px #fff;
    border-radius: 100px;
    background: #fff;
    height: 30px;
    width: 0;
}


@keyframes  load {
    0% {
        width: 0;
    }
    100% {
        width: 100%;
    }
}



    .uniform-dimension {
        width: 300px;  /* or any size you want */
        height: 200px; /* or any size you want */
        object-fit: cover; /* this will ensure that the aspect ratio of the image is maintained */
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<?php echo e(trans('student_courses.My Courses')); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('student_courses.My Courses')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <!-- Filter input field -->
    <div class="row mb-3">
        <div class="col-auto">
            <label for="filterTitle" class="col-form-label"><?php echo e(trans('student_courses.Filter by Course Title')); ?>

                :</label>
        </div>
        <div class="col">
            <input type="text" class="form-control" id="filterTitle">
        </div>
    </div>

    <div class="col-md-4 mb-3">
        <label for="filterDepartment" class="form-label"><?php echo e(trans('student_courses.Filter by Department')); ?>

            :</label>
        <select class="form-select" id="filterDepartment">
            <option value=""><?php echo e(trans('student_courses.All Departments')); ?>

            </option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($department->id); ?>"><?php echo e($department->Name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-4 mb-3">
        <label for="filterYear" class="form-label"><?php echo e(trans('student_courses.Filter by Year')); ?>

            :</label>
        <select class="form-select" id="filterYear">
            <option value=""><?php echo e(trans('student_courses.All Years')); ?>

            </option>
            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year->id); ?>"><?php echo e($year->Name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <?php
                $studentId = auth()->user()->id;
            
             $counter=0;
         ?>
            <div id="cardContainer" class="card-body" style="display: flex; flex-wrap: wrap;">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $counter++;
            ?>
                <?php if($course->published=="Active"): ?>
                <?php
                $studentCourse = DB::table('student_course')
                    ->where('student_id', $studentId)
                    ->where('course_id', $course->id)
                    ->first();

                $checkedItemsCounter = $studentCourse ? $studentCourse->checked_items_counter : 0;
                $totalItems = $course->item_counter;
                $percent = ($totalItems > 0) ? ($checkedItemsCounter / $totalItems) * 100 : 0;
                ?>

                <?php if($percent==100): ?>
                    <div class="card" style="width: 18rem; margin-right: 10px; margin-bottom: 10px;" data-department="<?php echo e(implode(',', $course->Department->pluck('id')->toArray())); ?>">
                        <img class="card-img-top uniform-dimension" src="<?php echo e($imag_dir.'/'.$course->time_stamp.$course->title.'/'.$course->images->filename); ?>" alt="Card image cap">
                        <div class="card-body">
                            <?php
                                $title_length = mb_strlen($course->title);
                                $description_length = mb_strlen($course->description);
                            ?>
                            <?php if($title_length > 18): ?>
                                <h5 class="card-title">
                                    <span id="titleShort<?php echo e($key); ?>"><?php echo e(Illuminate\Support\Str::limit($course->title, 18)); ?></span>
                                    <span id="titleFull<?php echo e($key); ?>" style="display: none;"><?php echo e($course->title); ?></span>
                                    <a href="#" onclick="toggleTitle(<?php echo e($key); ?>);"><?php echo e(trans('student_courses.Show More')); ?></a>
                                </h5>
                            <?php else: ?>
                                <h5 class="card-title"><?php echo e($course->title); ?></h5>
                                <div style="padding-top: 1.858rem; height: 1.858rem; display:block;"></div>
                            <?php endif; ?>
                            <p class="card-text"><?php echo e(trans('student_courses.Description')); ?>:<br>
                                <span id="descriptionShort<?php echo e($key); ?>"><?php echo e(Illuminate\Support\Str::limit($course->description, 30)); ?></span>
                                <span id="descriptionFull<?php echo e($key); ?>" style="display: none;"><?php echo e($course->description); ?></span>
                                <a href="#" onclick="toggleDescription(<?php echo e($key); ?>);">
                                    <?php if($description_length > 30): ?>
                                        <br><?php echo e(trans('student_courses.Show More')); ?>

                                    <?php else: ?>
                                        <br>
                                        <div style="padding-top: 0.95rem; height: 0.95rem; display:block;"></div>
                                    <?php endif; ?>
                                </a>
                            </p>
                            <p class="card-text"><?php echo e(trans('student_courses.Year')); ?>: <?php echo e($course->year_id); ?></p>
                            <p class="card-text"><?php echo e(trans('student_courses.Departments')); ?>:</p>
                            <ul id="departmentsShort<?php echo e($key); ?>">
                                <li><?php echo e($course->Department->first()->Name); ?></li>
                            </ul>
                            <ul id="departmentsFull<?php echo e($key); ?>" style="display: none;">
                                <?php $__currentLoopData = $course->Department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($department->Name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php if(count($course->Department) > 1): ?>
                                <br>
                                <a href="#" onclick="toggleDepartments(<?php echo e($key); ?>);"><?php echo e(trans('student_courses.Show More')); ?></a>
                            <?php else: ?>
                                <div style="padding-top: 0.95rem; height: 0.95rem; display:block;"></div>
                            <?php endif; ?>
                            <br>
                            <div class="chart" id="chart_<?php echo e($course->id); ?>" data-percent="<?php echo e(round($percent, 2)); ?>">
                                <div class="bar" id="bar_<?php echo e($course->id); ?>"></div>
                                <span id="value_<?php echo e($course->id); ?>"><?php echo e(round($percent, 2)); ?>%</span>
                            </div>
                            <br>
                            <div>
                            <a class="button" href="<?php echo e(route('Courses.editable', $course->id)); ?>"><?php echo e(trans('student_courses.Go somewhere')); ?></a>
                            <a class="button-trash" href="<?php echo e(route('Courses.remove', $course->id)); ?>"><?php echo e(trans('student_courses.Remove')); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($counter == 0): ?>
                        <table>
                            <tr>
                                <td class="text-center" colspan="5"><?php echo e(trans('student_courses.No courses found')); ?>!</td>
                            </tr>
                        </table>
                    <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
     document.addEventListener("DOMContentLoaded", function() {
        document.getElementById('filterTitle').addEventListener('input', filterCourses);
        document.getElementById('filterDepartment').addEventListener('change', filterCourses);

        function filterCourses() {
            var filterTitle = document.getElementById('filterTitle').value.toLowerCase();
            var selectedDepartments = Array.from(document.querySelectorAll('#filterDepartment option:checked')).map(option => option.value);

            var cards = document.querySelectorAll('#cardContainer .card');
            cards.forEach(function(card) {
                var title = card.querySelector('.card-title').textContent.toLowerCase();
                var departmentIds = card.getAttribute('data-department').split(',');

                var titleMatch = title.includes(filterTitle);
                var departmentMatch = (selectedDepartments.length === 0 || selectedDepartments.includes('') || selectedDepartments.some(selectedDepartment => departmentIds.includes(selectedDepartment)));

                card.style.display = (titleMatch && departmentMatch) ? 'block' : 'none';
            });
        }

        // Initialize all progress bars
        document.querySelectorAll('.chart').forEach(function(chart) {
            const id = chart.id.split('_')[1]; // Extract course ID from the element's ID
            increase(id);
        });

        function increase(courseId) {
            let SPEED = 16; // Speed of the animation, adjust as necessary
            let chart = document.getElementById("chart_" + courseId);
            let percent = parseFloat(chart.getAttribute('data-percent')); // Ensure percent is a float
            let bar = document.getElementById("bar_" + courseId);
            let value = document.getElementById("value_" + courseId);

            let i = 0;
            let interval = setInterval(function () {
                if (i >= percent) {
                    clearInterval(interval);
                } else {
                    i++;
                    value.innerHTML = i.toFixed(2) + "%"; // Update text with two decimal places
                    bar.style.width = i + "%"; // Update bar width
                }
            }, SPEED);
        }
    });

    //filtter by year
    document.getElementById('filterYear').addEventListener('change', filterCourses);

function filterCourses() {
    var filterTitle = document.getElementById('filterTitle').value.toLowerCase();
    var selectedDepartments = Array.from(document.querySelectorAll('#filterDepartment option:checked')).map(option => option.value);
    var selectedYear = document.getElementById('filterYear').value;

    var cards = document.querySelectorAll('#cardContainer .card');
    cards.forEach(function(card) {
        var title = card.querySelector('.card-title').textContent.toLowerCase();
        var departmentIds = card.getAttribute('data-department').split(',');
        var yearId = card.getAttribute('data-year');

        var titleMatch = title.includes(filterTitle);
        var departmentMatch = (selectedDepartments.length === 0 || selectedDepartments.includes('') || selectedDepartments.some(selectedDepartment => departmentIds.includes(selectedDepartment)));
        var yearMatch = (selectedYear === '' || selectedYear === yearId);

        if (titleMatch && departmentMatch && yearMatch) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}
function toggleTitle(key) {
        var shortTitle = document.getElementById('titleShort' + key);
        var fullTitle = document.getElementById('titleFull' + key);

        if (shortTitle.style.display === 'none') {
            shortTitle.style.display = 'inline';
            fullTitle.style.display = 'none';
        } else {
            shortTitle.style.display = 'none';
            fullTitle.style.display = 'inline';
        }
    }

    function toggleDescription(key) {
        var shortDescription = document.getElementById('descriptionShort' + key);
        var fullDescription = document.getElementById('descriptionFull' + key);

        if (shortDescription.style.display === 'none') {
            shortDescription.style.display = 'inline';
            fullDescription.style.display = 'none';
        } else {
            shortDescription.style.display = 'none';
            fullDescription.style.display = 'inline';
        }
    }

    function toggleDepartments(key) {
        var shortDepartments = document.getElementById('departmentsShort' + key);
        var fullDepartments = document.getElementById('departmentsFull' + key);

        if (shortDepartments.style.display === 'none') {
            shortDepartments.style.display = 'block';
            fullDepartments.style.display = 'none';
        } else {
            shortDepartments.style.display = 'none';
            fullDepartments.style.display = 'block';
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\new mohanned\pro2 new\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Students/dashboard/courses/my-completed-courses.blade.php ENDPATH**/ ?>