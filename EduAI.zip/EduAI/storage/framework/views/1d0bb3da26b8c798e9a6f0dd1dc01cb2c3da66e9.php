<div class="scrollbar side-menu-bg" style="overflow: scroll">
    <ul class="nav navbar-nav side-menu" id="sidebarnav">
        <!-- menu item Dashboard-->
        <li>
            <a href="<?php echo e(url('/teacher/dashboard')); ?>">
                <div class="pull-left"><i class="ti-home"></i><span
                        class="right-nav-text"><?php echo e(trans('main_trans.Dashboard')); ?></span>
                </div>
                <div class="clearfix"></div>
            </a>
        </li>
        <!-- menu title -->
        <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title"><?php echo e(trans('main_trans.Programname')); ?> </li>

        <!-- الملف الشخصي-->
        <li>
            <a href="<?php echo e(route('profile.show')); ?>"><i class="fas fa-id-card-alt"></i><span
                    class="right-nav-text">الملف الشخصي</span></a>
        </li>

        
        <!--كورسات-->
        

          <!--الدروس-->
          

          <!-- students-->
          <li>
            <a href="javascript:void(0);" data-toggle="collapse" data-target="#students-menu"><i class="fas fa-user-graduate"></i>كورسات<div class="pull-right"><i class="ti-plus"></i></div><div class="clearfix"></div></a>
            <ul id="students-menu" class="collapse">
                <li>
                    <a href="javascript:void(0);" data-toggle="collapse" data-target="#Student_information">معلومات الكورسات<div class="pull-right"><i class="ti-plus"></i></div><div class="clearfix"></div></a>
                    <ul id="Student_information" class="collapse">
                        <li> <a href="<?php echo e(route('lesson.index')); ?>"> قائمة الكورسات  </a></li>
                        <li> <a href="<?php echo e(route('courses.index')); ?>">اضافة كورس جديد</a></li>
                    </ul>
                </li>
            </ul>
        </li>


    </ul>
</div>
<?php /**PATH C:\Users\user\Desktop\project with quiz test\school-management-system-update_profile_in_dashboard_parent\resources\views/layouts/main-sidebar/teacher-main-sidebar.blade.php ENDPATH**/ ?>