<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>

    <style>
        .buttonLe {
            background: #84ba3f;
            padding: 2px 3px;
            font-size: 1rem;
            letter-spacing: 1px;
            border: 0;
            color: #ffffff;
            text-transform: uppercase;
            font-weight: 500;
            display: inline-block;
            border-radius: 3px;
            text-align: center;
            border: 2px solid #84ba3f;
            cursor: pointer;
            -webkit-transition: all 0.5s ease;
            -moz-transition: all 0.5s ease;
            -ms-transition: all 0.5s ease;
            -o-transition: all 0.5s ease;
            transition: all 0.5s ease;
        }
    </style>
<?php $__env->startSection('title'); ?>
<?php echo e(trans('teacher_courses.Add New Book')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('teacher_courses.Add New Book')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">

                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong><?php echo e(session()->get('error')); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <div class="col-xs-12">
                    <div class="col-md-12">
                        <br>
                        <form style="display:inline" action="<?php echo e(route('Item.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">

                                <div class="col">
                                    <label for="title"><?php echo e(trans('teacher_courses.Book Name')); ?>

                                    </label>
                                    <input type="text" name="title" class="form-control">
                                </div>
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <br>

                            <div class="col-md-5">
                                <div class="form-group text-center ">
                                    <label for="sections"><?php echo e(trans('teacher_courses.Sections')); ?><span
                                            class="text-danger"></span></label>
                                    <select class="custom-select mr-sm-2" name="section_id">
                                        <option selected disabled><?php echo e(trans('teacher_courses.Choose from the list')); ?>

                                            ...</option>
                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($section->course_id == $current_id): ?>
                                                <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['sections'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <br>
                            <div class="form-row">
                                <div class="col">
                                    <div class="form-group">
                                        <label for="academic_section"><?php echo e(trans('teacher_courses.Attachments')); ?>

                                            <span
                                                class="text-danger"></span></label>
                                        <input type="file" accept="application" name="file_name" required>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['file_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button class="button" type="submit"><?php echo e(trans('teacher_courses.Saving data')); ?>

                            </button>
                        </form>
                        <form style="display:inline" action="<?php echo e(route('lesson.editable', $current_id)); ?>" method="GET" class="mt-3">
                            <button type="submit" class="button-cancel"><?php echo e(trans('teacher_courses.Return')); ?>

                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\new mohanned\pro2\pro_2\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/create.blade.php ENDPATH**/ ?>