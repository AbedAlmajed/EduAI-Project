<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
<?php echo e(trans('teacher_courses.Add New Quiz')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('teacher_courses.Add New Quiz')); ?>


<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <div>
                    <div>
                        <div>
                            <form style="display:inline" method="post" action="<?php echo e(route('store.quiz')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input type="text" placeholder="<?php echo e(trans('teacher_courses.Quiz Title')); ?>" name="title" required class="form-control">
                                    

                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="<?php echo e(trans('teacher_courses.Duration in Minute')); ?>" name="duration" type="number" required>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group ">
                                        <label for="sections"><?php echo e(trans('teacher_courses.Sections')); ?><span class="text-danger"></span></label>
                                        <select class="custom-select mr-sm-2" name="section_id"  >
                                            <option selected disabled><?php echo e(trans('teacher_courses.Choose from the list')); ?>...</option>
                                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($section->course_id == $current_id): ?>
                                                <option  value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php $__errorArgs = ['sections'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                    <button class="button" type="submit"><?php echo e(trans('teacher_courses.Add')); ?></button>
                                
                            </form>
                            <form style="display:inline" action="<?php echo e(route('lesson.editable', $current_id)); ?>" method="GET" class="mt-3">
                                <button type="submit" class="button-cancel"><?php echo e(trans('teacher_courses.Return')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
                        </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>






















<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Downloads\school-management-system-update_profile_in_dashboard_parent\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/Quiz/add-quiz.blade.php ENDPATH**/ ?>