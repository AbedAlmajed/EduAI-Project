<div class="modal fade" id="EditSectionModal_<?php echo e($section->id); ?>" tabindex="-1" role="dialog" aria-labelledby="addSectionModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addSectionModalLabel">Edit Section</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('Section.update',$section->id)); ?>" method="post" >
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="section_name">Section Name:</label>
                        <input type="text" class="form-control" id="section_name" name="name" value="<?php echo e(old('name', isset($section) ? $section->name : '')); ?>">
                        <input type="hidden" name="id" value="<?php echo e($section->id); ?>" class="form-control">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Section</button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\Users\user\Desktop\Mohanned Project\New_version\school-management-system-update_profile_in_dashboard_parent (8)\school-management-system-update_profile_in_dashboard_parent\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/Section/edit.blade.php ENDPATH**/ ?>