<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e(trans('teacher_courses.Edit book')); ?> --<?php echo e($item->name); ?>--
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
--<?php echo e($item->name); ?>-- <?php echo e(trans('teacher_courses.Edit book')); ?> 
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">

                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('error')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="col-xs-12">
                        <div class="col-md-12">
                            <br>
                            <form action="<?php echo e(route('Item.update','test')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="form-row">

                                    <div class="col">
                                        <label for="title"><?php echo e(trans('teacher_courses.Book Name')); ?>

                                        </label>
                                        <input type="text" name="title" value="<?php echo e(old('name', isset($item) ? $item->name : '')); ?>"class="form-control">
                                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>" class="form-control">
                                    </div>

                                </div>
                                <br>

                                <div class="form-row">
                                    <div class="col">
                                        <?php
                                        $filePath = public_path('attachments/') . 'Items/' . $item->file_name;
                                        $mimeType = mime_content_type($filePath);

                                    ?>

<?php if(strpos($mimeType, 'video') !== false): ?>
<video controls width="500" height="300">
    <source src="<?php echo e(URL::asset('attachments/items/'.$item->file_name)); ?>" type="<?php echo e($mimeType); ?>">
    Your browser does not support the video tag.
</video>
<?php elseif(strpos($mimeType, 'image') !== false): ?>
<img src="<?php echo e(URL::asset('attachments/items/'.$item->file_name)); ?>" width="500" height="300" alt="Image">
<?php elseif(strpos($mimeType, 'application/pdf') !== false): ?>
<embed src="<?php echo e(URL::asset('attachments/items/'.$item->file_name)); ?>" type="application/pdf" height="500" width="500">
<?php else: ?>
<!-- Fallback for other file types -->
<a href="<?php echo e(URL::asset('attachments/items/'.$item->file_name)); ?>" target="_blank"><?php echo e(trans('teacher_courses.Download')); ?></a>
<?php endif; ?>
<br>
<br>

                                        <div class="form-group">
                                            <label for="academic_section"><?php echo e(trans('teacher_courses.Attachments')); ?><span class="text-danger"></span></label>
                                            <input type="file" accept="application/pdf"  name="file_name">
                                        </div>

                                    </div>
                                </div>
<br>
<div class="col-md-5">
    <div class="form-group text-center ">
        <label for="sections"><?php echo e(trans('teacher_courses.Sections')); ?><span class="text-danger"></span></label>
        <select class="custom-select mr-sm-2" name="section_id" required >
            <option selected disabled><?php echo e(trans('teacher_courses.Choose from the list')); ?>...</option>
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($section->course_id == $current_id): ?>
                <?php if($item->section_id == $section->id): ?>
                <option selected  value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                <?php else: ?>
                <option  value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div> 
</div> 
                                <button class="btn btn-success btn-sm nextBtn btn-lg pull-right" type="submit"><?php echo e(trans('teacher_courses.Saving data')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
    <script>
        $(document).ready(function () {
            $('select[name="Grade_id"]').on('change', function () {
                var Grade_id = $(this).val();
                if (Grade_id) {
                    $.ajax({
                        url: "<?php echo e(URL::to('classes')); ?>/" + Grade_id,
                        type: "GET",
                        dataType: "json",
                        success: function (data) {
                            $('select[name="Class_id"]').empty();
                            $.each(data, function (key, value) {
                                $('select[name="Class_id"]').append('<option value="' + key + '">' + value + '</option>');
                            });
                        },
                    });
                } else {
                    console.log('AJAX load did not work');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\new mohanned\pro2 new new\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/edit.blade.php ENDPATH**/ ?>