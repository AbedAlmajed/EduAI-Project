<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Courses List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    Courses List
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <!-- Filter input fields -->
    <div class="row mb-3">
        <div class="col-auto">
            <label for="filterTitle" class="col-form-label">Filter by Course Title:</label>
        </div>
        <div class="col">
            <input type="text" class="form-control" id="filterTitle">
        </div>
    </div>
    

    <div class="col-md-4 mb-3">
        <label for="filterDepartment" class="form-label">Filter by Department:</label>
        <select class="form-select" id="filterDepartment">
            <option value="">All Departments</option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($department->id); ?>"><?php echo e($department->Name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-4 mb-3">
        <label for="filterYear" class="form-label">Filter by Year:</label>
        <select class="form-select" id="filterYear">
            <option value="">All Years</option>
            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year->id); ?>"><?php echo e($year->Name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div id="cardContainer" class="card-body" style="display: flex; flex-wrap: wrap;">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($course->published == "Active"): ?>
                    <div class="card" style="width: 18rem; margin-right: 10px; margin-bottom: 10px;" data-department="<?php echo e(implode(',', $course->Department->pluck('id')->toArray())); ?>" data-year="<?php echo e($course->year_id); ?>">
                        <img class="card-img-top" src="<?php echo e($imag_dir); ?>/<?php echo e($course->time_stamp); ?><?php echo e($course->title); ?>/<?php echo e($course->images->filename); ?>" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($course->title); ?></h5>
                            <p class="card-text">Description: <?php echo e($course->description); ?></p>
                            <p class="card-text">Year: <?php echo e($course->year_id); ?></p>
                            <p class="card-text">Departments:</p>
                            <ul>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(in_array($department->id, $course->Department->pluck('id')->toArray())): ?>
                                        <li><?php echo e($department->Name); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <a class="btn btn-primary" href="<?php echo e(route('Courses.show', $course->id)); ?>">Go somewhere</a>
                            <a class="btn btn-primary" href="<?php echo e(route('Courses.add', $course->id)); ?>">Add TO List</a>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    // JavaScript for filtering by course title, department, and year
    document.getElementById('filterTitle').addEventListener('input', filterCourses);
    document.getElementById('filterDepartment').addEventListener('change', filterCourses);
    document.getElementById('filterYear').addEventListener('change', filterCourses);

    function filterCourses() {
        var filterTitle = document.getElementById('filterTitle').value.toLowerCase();
        var selectedDepartments = Array.from(document.querySelectorAll('#filterDepartment option:checked')).map(option => option.value);
        var selectedYear = document.getElementById('filterYear').value;

        var cards = document.querySelectorAll('#cardContainer .card');
        cards.forEach(function(card) {
            var title = card.querySelector('.card-title').textContent.toLowerCase();
            var departmentIds = card.getAttribute('data-department').split(',');
            var yearId = card.getAttribute('data-year');

            var titleMatch = title.includes(filterTitle);
            var departmentMatch = (selectedDepartments.length === 0 || selectedDepartments.includes('') || selectedDepartments.some(selectedDepartment => departmentIds.includes(selectedDepartment)));
            var yearMatch = (selectedYear === '' || selectedYear === yearId);

            if (titleMatch && departmentMatch && yearMatch) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\project with quiz test\start\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Students/dashboard/courses/index.blade.php ENDPATH**/ ?>