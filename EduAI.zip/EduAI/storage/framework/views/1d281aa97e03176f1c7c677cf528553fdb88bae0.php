<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Lesson management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('PageTitle'); ?>
    Lesson management
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->

<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <a href="<?php echo e(route('Item.create')); ?>" class="btn btn-success btn-sm" role="button" aria-pressed="true">اضافة كتاب جديد</a><br><br>
                <form action="<?php echo e(route('save-order')); ?>" method="POST"> <!-- Form starts here -->
                    <?php echo csrf_field(); ?> <!-- CSRF token -->
                    <p><br><br><br><br><br><br><?php echo e($current_id); ?><br><br><br>

                    <div id="sortable">
                        <?php $__currentLoopData = $items->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="align-items-start justify-content-center p-3" data-id="<?php echo e($item->id); ?>" style="background-color: #fff; border: 5px solid #eef5f9; display: block; text-align: center; width: 100%;">
                                <!-- Name of the item -->
                                <b style="width: 100%; position: relative; letter-spacing: 2.63px; line-height: 32px; display: block; margin-bottom: 10px;"><?php echo e($item->name); ?></b>
                                <?php
                                    $filePath = public_path('attachments/') . 'Items/' . $item->file_name;
                                    $mimeType = mime_content_type($filePath);
                                ?>
                                
                                <?php if(strpos($mimeType, 'video') !== false): ?>
                                    <!-- Display video -->
                                    <video controls width="300" style="display: inline-block;">
                                        <source src="<?php echo e(asset('attachments/Items/' . $item->file_name)); ?>" type="<?php echo e($mimeType); ?>">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php elseif(strpos($mimeType, 'image') !== false): ?>
                                    <!-- Display image -->
                                    <img src="<?php echo e(asset('attachments/Items/'. $item->file_name)); ?>" alt="<?php echo e($item->name); ?>" width="300" style="display: inline-block;">
                                <?php elseif(strpos($mimeType, 'application/pdf') !== false): ?>
                                    <!-- Display PDF document -->
                                    <a href="<?php echo e(asset('attachments/Items/' . $item->file_name)); ?>" target="_blank">View PDF Document</a>
                                <?php elseif(strpos($mimeType, 'application/msword') !== false): ?>
                                    <!-- Display Word document -->
                                    <a href="<?php echo e(asset('attachments/Items/'. $item->file_name)); ?>" target="_blank">View Word Document</a>
                                <?php else: ?>
                                    <!-- Display other file types (e.g., URLs) -->
                                    <a href="<?php echo e($item->file_name); ?>" target="_blank"><?php echo e($item->name); ?></a>
                                <?php endif; ?>
                        
                                <!-- Other buttons (download, edit, delete) go here -->
                                <div style="margin-top: 10px;">
                                    <a href="<?php echo e(route('downloadAttachment', $item->file_name)); ?>" title="تحميل الكتاب" class="btn btn-warning btn-sm" role="button" aria-pressed="true"><i class="fas fa-download"></i> Download</a>
                                    <a href="<?php echo e(route('Item.edit', $item->id)); ?>" class="btn btn-info btn-sm" role="button" aria-pressed="true"><i class="fa fa-edit"></i> Edit</a>
                                    <button type="button" class="btn btn-danger btn-sm" onclick="toggleDeleteModal(<?php echo e($item->id); ?>)" title="حذف"><i class="fa fa-trash"></i> Delete</button>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <input type="hidden" name="tag_order" id="tag_order"> <!-- Hidden input field to store tag order -->

                    <br>
                    <br><br><br><br><br><br><br><br></p>
                    
                    <button type="submit" class="btn btn-primary">Submit</button> <!-- Submit button -->
                </form> <!-- Form ends here -->
            </div>
        </div>
    </div>
</div>
<!-- row closed -->

<!-- Modal -->
<?php $__currentLoopData = $items->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('pages.Teachers.Lesson.destroy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    function toggleDeleteModal(itemId) {
        $('#delete_item_' + itemId).modal('toggle');
    }
    $(function() {
        $("#sortable").sortable({
            update: function(event, ui) {
                // Get the order of the tags
                var tagOrder = $("#sortable").sortable("toArray", { attribute: "data-id" });
                // Update the value of the hidden input field
                $("#tag_order").val(tagOrder.join(","));
            }
        });
        $("#sortable").disableSelection();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Project Backup\mohanned\school-management-system-update_profile_in_dashboard_parent (2)\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/lesson_management.blade.php ENDPATH**/ ?>