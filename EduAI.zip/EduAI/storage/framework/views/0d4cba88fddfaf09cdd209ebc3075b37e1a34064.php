<div class="modal fade" id="delete_section_<?php echo e($section->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('Section.destroy', $section->id)); ?>" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">حذف كتاب</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p><?php echo e(trans('My_Classes_trans.Warning_Grade')); ?> <span class="text-danger"><?php echo e($section->title); ?></span></p>
                    <input type="hidden" name="id" value="<?php echo e($section->id); ?>">
                </div>
                <div class="modal-footer">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(trans('My_Classes_trans.Close')); ?></button>
                        <button type="submit" class="btn btn-danger"><?php echo e(trans('My_Classes_trans.submit')); ?></button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\user\Desktop\mohannad\school-management-system-update_profile_in_dashboard_parent\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/Section/destroy.blade.php ENDPATH**/ ?>