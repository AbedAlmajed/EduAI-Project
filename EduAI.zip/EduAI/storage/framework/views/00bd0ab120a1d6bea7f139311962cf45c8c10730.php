<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
Add New Quiz

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
Add New Quiz

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <div>
                    <div>
                        <div>
                            <form method="post" action="<?php echo e(route('store.quiz')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input type="text" placeholder="Quiz Title" name="title" required class="form-control">
                                    <label>Valid From</label>
                                    <input name="from_time" type="datetime-local">
                                    <label>Valid Till</label>
                                    <input name="to_time" type="datetime-local">
            
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Duration in Minute" name="duration" type="number" required>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group text-center ">
                                        <label for="sections"><?php echo e(__('Sections')); ?> :<span class="text-danger">*</span></label>
                                        <select class="custom-select mr-sm-2" name="section_id"  >
                                            <option selected disabled><?php echo e(trans('Parent_trans.Choose')); ?>...</option>
                                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($section->course_id == $current_id): ?>
                                                <option  value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php $__errorArgs = ['sections'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="text-center">
                                    <button class="btn btn-primary" type="submit">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                        </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\project with quiz test\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/Quiz/add-quiz.blade.php ENDPATH**/ ?>