<?php $__env->startSection('css'); ?>
<style>
  .dropdown {
    position: relative;
    display: block; /* Change display to block */
  }

  .dropdown-toggle {
    text-align: left;
    background-color: #f1f1f1;
    border: none;
    padding: 12px 4px 4px 4px ;
  }

  .dropdown-toggle::after {
    content: '\25BC'; /* Unicode character for down arrow */
    float: right; /* Align the arrow to the right */
    margin-left: 5px; /* Add some spacing between the text and the arrow */
  }

  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    z-index: 1;
    width: 100%; /* Set width to 100% */
  }

  .dropdown-content a:hover {
    background-color: #f1f1f1;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Lesson management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('PageTitle'); ?>
Lesson management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <input type="hidden" id="course_id" name="course_id" value="<?php echo e($current_id); ?>"/>
                                <?php
                                 $studentId=auth()->user()->id;
                                 ?>



                <br> <br>
                <!-- Modal -->


                    <?php $__currentLoopData = $sections->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($section->course_id==$current_id): ?>
                    <div class="row draggable-section" data-section-id="<?php echo e($section->id); ?>">
                        <div class="col-md-12" style="width: 100%; position: relative; display: block">
                            <!-- Move the .dropdown-toggle button outside the column container -->
                            <div style="display: flex; align-items: center;">
                                <button type="button" class="dropdown-toggle" onclick="toggleDropdown('<?php echo e($section->id); ?>')" style="width: 100%; text-align: left; position: relative;">
                                    <span style="display: inline-block;">
                                        <?php echo e($section->name); ?>

                                    </span>


                                </button>
                            </div>
                        </div>
                    </div>
                    <br><br>
                    <div class="dropdown">
                        <div class="dropdown-content" id="dropdownContent<?php echo e($section->id); ?>">
                            <div class="sortable">
                                <?php $__currentLoopData = $items->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($section->id===$item->section_id): ?>
                                <div class="align-items-start justify-content-center p-3" data-id="<?php echo e($item->id); ?>" style="background-color: #fff; border: 5px solid #eef5f9; display: block; text-align: center; width: 100%;">
                                        <b style="width: 100%; position: relative; letter-spacing: 2.63px; line-height: 32px; display: block; margin-bottom: 10px;"><?php echo e($item->name); ?></b>
                                        <?php
                                        $itemId = $item->id;// the ID of the item

                                        $record = DB::table('student_item')
                                            ->where('student_id', $studentId)
                                            ->where('item_id', $itemId)
                                            ->first();
                                        $isChecked = $record ? $record->checked : 0;
                                    ?>
                                        <input type="checkbox" class="checkbox" value="<?php echo e($itemId); ?>" <?php if($isChecked): ?> checked <?php endif; ?>>
                                        <label for="checkbox">Checked</label>
                                  <?php
                                            $filePath = public_path('attachments/') . 'Items/' . $item->file_name;
                                            $mimeType = mime_content_type($filePath);
                                            $fileContent = file_get_contents(public_path('attachments/Items/'.$item->file_name));
                                            $first60Chars = substr($fileContent, 0, 60);
                                            $expectedString = '$2y$10$icrfILR/E1R9cV0AGrYw.OgJm6mylyyI8sS6jaTXn896e75CCP/Fq';
                                            $matchesExpected = ($first60Chars === $expectedString && substr($item->file_name, 10)==="Youtube_Video.txt");
                                            $after60Chars = substr($fileContent, 60);
                                        ?>
                                        <?php if($item->wysiwyg_id===-1 && $item->quiz_id===-1): ?>
                                            <?php if(strpos($mimeType, 'video') !== false): ?>
                                                <video controls width="300" style="display: inline-block;">
                                                    <source src="<?php echo e(asset('attachments/Items/' . $item->file_name)); ?>" type="<?php echo e($mimeType); ?>">
                                                    Your browser does not support the video tag.
                                                </video>
                                            <?php elseif(strpos($mimeType, 'image') !== false): ?>
                                                <img src="<?php echo e(asset('attachments/Items/'. $item->file_name)); ?>" alt="<?php echo e($item->name); ?>" width="300" style="display: inline-block;">
                                            <?php elseif(strpos($mimeType, 'application/pdf') !== false): ?>
                                                <a href="<?php echo e(asset('attachments/Items/' . $item->file_name)); ?>" target="_blank">View PDF Document</a>
                                            <?php elseif(strpos($mimeType, 'application/msword') !== false): ?>
                                                <a href="<?php echo e(asset('attachments/Items/'. $item->file_name)); ?>" target="_blank">View Word Document</a>
                                            <?php else: ?>
                                                <?php if($matchesExpected==true): ?>
                                                    <iframe class="embed-responsive-item" width="640" height="360" src="<?php echo e($after60Chars); ?>" title="<?php echo e($item->name); ?>" allowfullscreen style="max-width: 100%;"></iframe>
                                                <?php else: ?>
                                                    <a href="<?php echo e($item->file_name); ?>" target="_blank"><?php echo e($item->name); ?></a>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <div style="margin-top: 10px;">
                                                    <?php if($matchesExpected!=true): ?>
                                                        <a href="<?php echo e(route('downloadBook', $item->file_name)); ?>" title="تحميل الكتاب" class="btn btn-warning btn-sm " role="button" aria-pressed="true"><i class="fas fa-download"></i> Download</a>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php elseif($item->wysiwyg_id !=-1): ?>
                                                    <?php
                                                        $post = \App\Models\Post::findOrFail($item->wysiwyg_id);
                                                    ?>
                                                    <div>
                                                        <?php echo $post->description; ?>

                                                    </div>

                                                    <?php else: ?>
                                                    <?php if($item->quiz_id != -1): ?>
                                                    <?php
                                                    $quiz = \App\Models\Quiz::findOrFail($item->quiz_id);
                                                    ?>
                                                    <table class="table">
                                                        <tr>
                                                            <td><?php echo e($quiz->title); ?></td>
                                                            <td><?php echo e($quiz->from_time); ?></td>
                                                            <td><?php echo e($quiz->to_time); ?></td>
                                                            <td><?php echo e($quiz->duration); ?> minutes</td>
                                                            <td><a href="/give-quiz/<?php echo e($quiz->id); ?>"><?php echo e($quiz->title); ?></a></td>

                                                        </tr>
                                                    </table>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div id="dropdownMargin<?php echo e($section->id); ?>"></div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>

    <script>
        function toggleDropdown(sectionId) {
            var dropdownContent = document.getElementById("dropdownContent" + sectionId);
            var dropdownMargin = document.getElementById("dropdownMargin" + sectionId);

            if (dropdownContent.style.display === "none") {
                dropdownContent.style.display = "block";
                dropdownMargin.style.marginBottom = dropdownContent.clientHeight + "px";
            } else {
                dropdownContent.style.display = "none";
                dropdownMargin.style.marginBottom = "0";
            }
        }

        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.dropdown-toggle')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.style.display === "block") {
                        openDropdown.style.display = "none";
                        var sectionId = openDropdown.id.replace('dropdownContent', '');
                        document.getElementById("dropdownMargin" + sectionId).style.marginBottom = "0";
                    }
                }
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            var checkboxes = document.querySelectorAll('.checkbox');
            checkboxes.forEach(function(checkbox) {
                checkbox.addEventListener('change', function() {
                    var isChecked = this.checked ? 1 : 0; // Convert boolean to integer
                    var itemId = this.value;

                    // Create a new XMLHttpRequest for updating checkbox state
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', '/updateCheckbox', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

                    // Handle the response
                    xhr.onload = function() {
                        if (xhr.status === 200) {
                            console.log(xhr.responseText);
                        } else {
                            console.error(xhr.responseText);
                        }
                    };

                    // Send the AJAX request to update checkbox state
                    var data = '_token=' + encodeURIComponent('<?php echo e(csrf_token()); ?>') +
                        '&item_id=' + encodeURIComponent(itemId) +
                        '&checked=' + encodeURIComponent(isChecked);
                    xhr.send(data);

                    // Create a new XMLHttpRequest for updating checked items counter
                    var counterXhr = new XMLHttpRequest();
                    counterXhr.open('POST', '/updateCheckedItemsCounter', true);
                    counterXhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

                    // Handle the response
                    counterXhr.onload = function() {
                        if (counterXhr.status === 200) {
                            console.log(counterXhr.responseText);
                        } else {
                            console.error(counterXhr.responseText);
                        }
                    };

                    // Send the AJAX request to update checked items counter
                    var counterData = '_token=' + encodeURIComponent('<?php echo e(csrf_token()); ?>') +
                        '&course_id=' + encodeURIComponent(document.getElementById('course_id').value);
                    counterXhr.send(counterData);
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NTC\Desktop\pro_2\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Students/dashboard/courses/lesson_management.blade.php ENDPATH**/ ?>