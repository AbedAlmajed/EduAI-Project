<?php $__env->startSection('css'); ?>
<style>
  .dropdown {
    position: relative;
    display: block; /* Change display to block */
  }

  .dropdown-toggle {
    text-align: left;
    background-color: #f1f1f1;
    border: none;
    padding: 12px 4px 4px 4px ;
  }

  .dropdown-toggle::after {
    content: '\25BC'; /* Unicode character for down arrow */
    float: right; /* Align the arrow to the right */
    margin-left: 5px; /* Add some spacing between the text and the arrow */
  }

  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    z-index: 1;
    width: 100%; /* Set width to 100% */
  }

  .dropdown-content a:hover {
    background-color: #f1f1f1;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Lesson management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('PageTitle'); ?>
Lesson management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                  <span class="dropdown show"  style="position: absolute; right: 270px; top: 17.5px;">
                                        <a class="btn btn-success btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            العمليات
                                        </a>
                                        <span class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                            <a class="dropdown-item" href="<?php echo e(route('Item.create',$current_id)); ?>" ><i style="color:green" class="fa fa-edit"></i>&nbsp; Add new book</a>
                                            <a class="dropdown-item"  href="<?php echo e(route('Item.create_youtube_url',$current_id)); ?>" ><i style="color:green" class="fa fa-edit"></i>&nbsp; Add Youtube Link</a>
                                            <a class="dropdown-item"  href="<?php echo e(route('WYSIWYG.create',$current_id)); ?>"><i style="color:green" class="fa fa-edit"></i>&nbsp; Add new post</a>
                                         

                                        </span>
                                    </span>
                                    <span class="dropdown show"  style="position: absolute; right: 350px; top: 17.5px;">
                                        <a class="btn btn-success btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                           (كويز) العمليات
                                        </a>
                                        <span class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                            <a class="dropdown-item" href="<?php echo e(route('add.quiz',$current_id)); ?>" ><i style="color:green" class="fa fa-edit"></i>&nbsp; Add Quiz</a>
                                            <a class="dropdown-item"  href="<?php echo e(route('list.quiz')); ?>" ><i style="color:green" class="fa fa-edit"></i>&nbsp; Quiz List</a>
                                            <a class="dropdown-item"  href="<?php echo e(route('results')); ?>"><i style="color:green" class="fa fa-edit"></i>&nbsp; Results</a>
                                         

                                        </span>
                                    </span>
              
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addSectionModal">Add New Section</button>

            <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#EditSectionsPositionModal" aria-pressed="true"><i class="fa fa-edit"></i> Edit Sections Position</button>

                <br> <br>
                <!-- Modal -->

                <form action="<?php echo e(route('save-order')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php $__currentLoopData = $sections->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($section->course_id==$current_id): ?>
                    <div class="row draggable-section" data-section-id="<?php echo e($section->id); ?>">
                        <div class="col-md-12" style="width: 100%; position: relative; display: block">
                            <!-- Move the .dropdown-toggle button outside the column container -->
                            <div style="display: flex; align-items: center;">
                                <button type="button" class="dropdown-toggle" onclick="toggleDropdown('<?php echo e($section->id); ?>')" style="width: 100%; text-align: left; position: relative;">
                                    <span style="display: inline-block;">
                                        <?php echo e($section->name); ?>

                                    </span>
                                 
                                    <span class="dropdown show" style="position: absolute; right: 50px; top: 5px;">
                                        <a class="btn btn-success btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            العمليات
                                        </a>
                                        <span class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                            <a class="dropdown-item" onclick="toggleEditModalSection('<?php echo e($section->id); ?>')" ><i style="color:green" class="fa fa-edit"></i>&nbsp; Edit Section</a>
                                            <a class="dropdown-item"  onclick="toggleDeleteModalSection('<?php echo e($section->id); ?>')" data-toggle="modal"><i style="color: red" class="fa fa-trash"></i>&nbsp; Delete Section</a>
                                        </span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <br><br>
                    <div class="dropdown">
                        <div class="dropdown-content" id="dropdownContent<?php echo e($section->id); ?>">
                            <div class="sortable">
                                <?php $__currentLoopData = $items->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($section->id===$item->section_id): ?>
                                <div class="align-items-start justify-content-center p-3" data-id="<?php echo e($item->id); ?>" style="background-color: #fff; border: 5px solid #eef5f9; display: block; text-align: center; width: 100%;">
                                        <b style="width: 100%; position: relative; letter-spacing: 2.63px; line-height: 32px; display: block; margin-bottom: 10px;"><?php echo e($item->name); ?></b>
                                        <?php
                                            $filePath = public_path('attachments/') . 'Items/' . $item->file_name;
                                            $mimeType = mime_content_type($filePath);
                                            $fileContent = file_get_contents(public_path('attachments/Items/'.$item->file_name));
                                            $first60Chars = substr($fileContent, 0, 60);
                                            $expectedString = '$2y$10$icrfILR/E1R9cV0AGrYw.OgJm6mylyyI8sS6jaTXn896e75CCP/Fq';
                                            $matchesExpected = ($first60Chars === $expectedString && substr($item->file_name, 10)==="Youtube_Video.txt");
                                            $after60Chars = substr($fileContent, 60);
                                        ?>
                                        <?php if($item->wysiwyg_id===-1 && $item->quiz_id===-1): ?>
                                            <?php if(strpos($mimeType, 'video') !== false): ?>
                                                <video controls width="300" style="display: inline-block;">
                                                    <source src="<?php echo e(asset('attachments/Items/' . $item->file_name)); ?>" type="<?php echo e($mimeType); ?>">
                                                    Your browser does not support the video tag.
                                                </video>
                                            <?php elseif(strpos($mimeType, 'image') !== false): ?>
                                                <img src="<?php echo e(asset('attachments/Items/'. $item->file_name)); ?>" alt="<?php echo e($item->name); ?>" width="300" style="display: inline-block;">
                                            <?php elseif(strpos($mimeType, 'application/pdf') !== false): ?>
                                                <a href="<?php echo e(asset('attachments/Items/' . $item->file_name)); ?>" target="_blank">View PDF Document</a>
                                            <?php elseif(strpos($mimeType, 'application/msword') !== false): ?>
                                                <a href="<?php echo e(asset('attachments/Items/'. $item->file_name)); ?>" target="_blank">View Word Document</a>
                                            <?php else: ?>
                                                <?php if($matchesExpected==true): ?>
                                                    <iframe class="embed-responsive-item" width="640" height="360" src="<?php echo e($after60Chars); ?>" title="<?php echo e($item->name); ?>" allowfullscreen style="max-width: 100%;"></iframe>
                                                <?php else: ?>
                                                    <a href="<?php echo e($item->file_name); ?>" target="_blank"><?php echo e($item->name); ?></a>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <div style="margin-top: 10px;">
                                                    <?php if($matchesExpected!=true): ?>
                                                        <a href="<?php echo e(route('downloadAttachment', $item->file_name)); ?>" title="تحميل الكتاب" class="btn btn-warning btn-sm " role="button" aria-pressed="true"><i class="fas fa-download"></i> Download</a>
                                                        <a href="<?php echo e(route('Item.edit',['id' => $item->id, 'current_id' => $current_id])); ?>" class="btn btn-info btn-sm " role="button" aria-pressed="true"><i class="fa fa-edit"></i> Edit</a>
                                                        <?php endif; ?>
                                                        <button type="button" class="btn btn-danger btn-sm" onclick="toggleDeleteModal(<?php echo e($item->id); ?>)" title="حذف"><i class="fa fa-trash"></i> Delete</button>
                                                    </div>
                                                <?php elseif($item->wysiwyg_id !=-1): ?>
                                                    <?php
                                                        $post = \App\Models\Post::findOrFail($item->wysiwyg_id);
                                                    ?>
                                                    <div>
                                                        <?php echo $post->description; ?>

                                                    </div>
                                                    <a href="<?php echo e(route('WYSIWYG.edit', ['id' => $item->wysiwyg_id, 'course_id' => $current_id, 'item_id'=>$item->id])); ?>" class="btn btn-info btn-sm" role="button" aria-pressed="true">
                                                        <i class="fa fa-edit"></i> Edit
                                                    </a>
                                                    <button type="button" class="btn btn-danger btn-sm" onclick="toggleDeleteModal(<?php echo e($item->id); ?>)" title="حذف"><i class="fa fa-trash"></i> Delete</button>
                                                    <?php else: ?>
                                                    <?php
                                                    $quiz = \App\Models\Quiz::findOrFail($item->quiz_id);
                                                    ?>
                                                    <table class="table">
                                                        <tr>
                                                            <td><a href="/add-question/<?php echo e($quiz->id); ?>" target="_blank"><?php echo e($quiz->title); ?></a></td>
                                                            <td><?php echo e($quiz->from_time); ?></td>
                                                            <td><?php echo e($quiz->to_time); ?></td>
                                                            <td><?php echo e($quiz->duration); ?> minutes</td>
                                                        </tr>
                                                    </table>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div id="dropdownMargin<?php echo e($section->id); ?>"></div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <input type="hidden" name="tag_order" id="tag_order">
                        <br>
                        <br><br><br><br><br><br><br><br>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($item)): ?>
            <?php echo $__env->make('pages.Teachers.Lesson.destroy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo $__env->make('pages.Teachers.Lesson.Section.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($section)): ?>
            <?php echo $__env->make('pages.Teachers.Lesson.Section.destroy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($section)): ?>
            <?php echo $__env->make('pages.Teachers.Lesson.Section.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('pages.Teachers.Lesson.Section.edit_Postions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $(document).ready(function() {
        // Event delegation for dynamically generated elements
        $(document).on('sortable', '.draggable-section', function() {
            $(this).sortable({
                handle: ".dropdown-toggle", // Set the handle to the dropdown-toggle button
                update: function(event, ui) {
                    updateSectionOrder();
                }
            });
        });


        // Initialize sortable for existing and dynamically added draggable-section elements
        $(".draggable-section").trigger('sortable');
    });

    function updateSectionOrder() {
        var sectionOrder = [];
        $(".draggable-section").each(function() {
            sectionOrder.push($(this).data('section-id'));
        });
        // Here you can update the order of sections as needed
        console.log("Section Order:", sectionOrder);
    }

    function toggleDeleteModal(itemId) {
        $('#delete_item_' + itemId).modal('toggle');
    }

    function toggleDeleteModalSection(sectionId) {
        $('#delete_section_' + sectionId).modal('toggle');
    }

    function toggleEditModalSection(sectionId) {
        $('#EditSectionModal_' + sectionId).modal('toggle');
    }

    $(function() {
        $(".sortable").sortable({
            update: function(event, ui) {
                updateTagOrder();
            }
        }).disableSelection();
    });

    function updateTagOrder() {
        var tagOrder = [];
        $(".sortable").each(function() {
            $(this).find('> div').each(function() {
                tagOrder.push($(this).attr('data-id'));
            });
        });
        $("#tag_order").val(tagOrder.join(","));
    }

    function toggleDropdown(sectionId) {
        var dropdownContent = document.getElementById("dropdownContent" + sectionId);
        var dropdownMargin = document.getElementById("dropdownMargin" + sectionId);

        if (dropdownContent.style.display === "none") {
            dropdownContent.style.display = "block";
            dropdownMargin.style.marginBottom = dropdownContent.clientHeight + "px";
        } else {
            dropdownContent.style.display = "none";
            dropdownMargin.style.marginBottom = "0";
        }
    }

    // Close the dropdown if the user clicks outside of it
    window.onclick = function(event) {
        if (!event.target.matches('.dropdown-toggle')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            for (var i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.style.display === "block") {
                    openDropdown.style.display = "none";
                    var sectionId = openDropdown.id.replace('dropdownContent', '');
                    document.getElementById("dropdownMargin" + sectionId).style.marginBottom = "0";
                }
            }
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\project with quiz test\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/lesson_management.blade.php ENDPATH**/ ?>