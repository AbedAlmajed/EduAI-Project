<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    Result List
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    Result List

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">

                <div class="text-center">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Title</th>
                                <th scope="col">Quiz Score</th>
                                <?php if(auth('teacher')->check()): ?>
                                    <th scope="col">User Score</th>
                                    <th scope="col">User Name</th>
                                <?php else: ?>
                                    <th scope="col">My Score</th>
                                <?php endif; ?>
                                <th scope="col">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sl = 1;
                            ?>
                            <?php $__currentLoopData = $shows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($sl++); ?></th>
                                    <td><?php echo e($show->title); ?></td>
                                    <td><?php echo e($show->quiz_score); ?></td>
                                    <td><?php echo e($show->achieved_score); ?></td>
                                    <?php if(auth('teacher')->check()): ?>
                                        <td><?php echo e($show->getTranslation('student_name', app()->getLocale())); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($show->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <form style="display:inline" action="<?php echo e(route('lesson.editable', $current_id)); ?>" method="GET"
                    class="mt-3">
                    <button type="submit" class="button-cancel">Return</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Downloads\product22\product22\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/Quiz/user/result-page.blade.php ENDPATH**/ ?>