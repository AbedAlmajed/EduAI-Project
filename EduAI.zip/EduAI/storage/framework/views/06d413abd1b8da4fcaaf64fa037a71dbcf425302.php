<?php $__env->startSection('css'); ?>
<style>
  .dropdown {
    position: relative;
    display: block; /* Change display to block */
  }

  .dropdown-toggle {
    text-align: left;
    background-color: #f1f1f1;
    border: none;
    padding: 12px 4px 4px 4px ;
  }

  .dropdown-toggle::after {
    content: '\25BC'; /* Unicode character for down arrow */
    float: right; /* Align the arrow to the right */
    margin-left: 5px; /* Add some spacing between the text and the arrow */
  }

  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    z-index: 1;
    width: 100%; /* Set width to 100% */
  }

  .dropdown-content a:hover {
    background-color: #f1f1f1;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Lesson management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('PageTitle'); ?>
Lesson management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <br><br>
                    <!-- Modal -->
                    <?php $__currentLoopData = $sections->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($section->course_id == $current_id): ?>
                            <div class="row draggable-section" data-section-id="<?php echo e($section->id); ?>">
                                <div class="col-md-12" style="width: 100%; position: relative; display: block">
                                    <!-- Move the .dropdown-toggle button outside the column container -->
                                    <div style="display: flex; align-items: center;">
                                        <button type="button" class="dropdown-toggle" onclick="toggleDropdown('<?php echo e($section->id); ?>')" style="width: 100%; text-align: left; position: relative;">
                                            <span style="display: inline-block;">
                                                <?php echo e($section->name); ?>

                                            </span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <br><br>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\project with quiz test\mohanned\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Students/dashboard/courses/show_course.blade.php ENDPATH**/ ?>