<!-- Delete modal -->
<div class="modal fade" id="deleteModal<?php echo e($question->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">حذف كتاب</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                هل انت متأكد من عملية الحذف؟
            </div>
            <div class="modal-footer">
                <!-- Form to submit delete action -->
                <form id="deleteForm<?php echo e($question->id); ?>" action="<?php echo e(route('delete.question', ['id' => $question->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <!-- Submit button -->
                    <button type="submit" class="btn btn-danger">حذف</button>
                </form>
                <!-- Button to close the modal -->
                <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
            </div>
        </div>
    </div>
</div>

<script>
    
    function deleteQuestion(questionId) {
        $('#deleteForm'+questionId).submit();
    }
</script><?php /**PATH C:\Users\moham\Downloads\product22\product22\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/Quiz/delete-modal.blade.php ENDPATH**/ ?>