<?php $__env->startSection('css'); ?>
<!-- Additional CSS to adjust columns for titles and descriptions -->
<style>
    /* Adjust columns to allow text wrapping */
    th, td {
        overflow: hidden;
    }

    /* Allow the titles and descriptions to wrap as paragraphs */
    td:first-child, /* Title column */
    td:nth-child(2) { /* Description column */
        white-space: normal;
        word-wrap: break-word;
        max-width: 300px; /* Adjust as needed */
    }

    /* Resize images */
    td:nth-child(3) img {
        max-width: 100px; /* Adjust as needed */
        height: auto;
    }
</style>
<?php $__env->startSection('title'); ?>
    Courses List
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
Courses List
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="title d-flex justify-content-between">
    <p>
        <a href="<?php echo e(route('courses.create')); ?>" class="button">Add New</a>
    </p>
</div>
<br>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="datatable" class="table table-bordered table-striped table-hover datatable datatable-Location">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Course Image</th>
                        <th>Published</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Auth::user()->id === $course->teacher_id): ?>
                <?php $counter++ ?>
                    <tr data-entry-id="<?php echo e($course->id); ?>">
                        <td style="word-wrap: break-word;"><?php echo e($course->title ?? ''); ?></td>
                        <td style="word-wrap: break-word; max-width: 300px;"><?php echo e($course->description ?? ''); ?></td>
                        <td>
                            <img src="<?php echo e($imag_dir . '/' . $course->time_stamp . $course->title . '/' . $course->images->filename); ?>" alt="Course Image" width="150" />
                        </td>
                        <td><?php echo e($course->published); ?></td>
                        <td>
                            <a class="btn btn-xs btn-info" href="<?php echo e(route('courses.edit', $course->id)); ?>">Edit</a>
                            <button type="button" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#delete_Course<?php echo e($course->id); ?>">
                                Delete
                            </button>
                            <div class="modal fade" id="delete_Course<?php echo e($course->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <form action="<?php echo e(route('courses.destroy', $course->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Delete Course</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Are you sure you want to delete this course?</p>
                                                <input type="hidden" name="id" value="<?php echo e($course->id); ?>">
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($counter == 0): ?>
                    <tr>
                        <td class="text-center" colspan="5">No courses found!</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Downloads\product22\product22\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/courses/index.blade.php ENDPATH**/ ?>