
<div class="modal fade" id="EditSectionsPositionModal" tabindex="-1" role="dialog" aria-labelledby="addSectionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addSectionModalLabel">Edit Section</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Section Name Form -->
                <form id="sectionOrderForm" action="<?php echo e(route('Section.updateOrder')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <ul class="list-group sortable">
                        <?php $__currentLoopData = $sections->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item" data-section-id="<?php echo e($section->id); ?>">
                                <?php echo e($section->name); ?>

                                <input type="hidden" name="section_order[<?php echo e($index); ?>][id]" value="<?php echo e($section->id); ?>">
                                <input type="hidden" name="section_order[<?php echo e($index); ?>][position]" value="<?php echo e($index); ?>">
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="submit" class="btn btn-primary">Save Section Order</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<?php $__env->startPush('scripts'); ?>
<!-- Include jQuery and jQuery UI Sortable -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>

    <!-- Define the saveSectionOrder function -->
    <script>
        $(document).ready(function() {
        // Make sections draggable
        $(".sortable").sortable();

        // Update hidden input fields when the order changes
        $(".sortable").on("sortupdate", function(event, ui) {
            $(".sortable li").each(function(index) {
                $(this).find("input[name='section_order[" + index + "][position]']").val(index);
            });
        });
    });
        // Define the saveSectionOrder function
        function saveSectionOrder() {
            var sectionOrder = [];
            $(".sortable li").each(function(index) {
                sectionOrder.push($(this).attr('data-section-id'));
            });

            // Send the updated section order to the server to save
            $.ajax({
                url: "<?php echo e(route('Section.updateOrder')); ?>",
                method: "POST",
                data: {
                    section_order: sectionOrder,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(response) {
                    console.log("Section order updated successfully");
                    // Close the modal after saving the order
                    $('#EditSectionsPositionModal').modal('hide');
                },
                error: function(xhr, status, error) {
                    console.error("Error updating section order:", error);
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH C:\Users\user\Desktop\Mohannad\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/Section/edit_Postions.blade.php ENDPATH**/ ?>