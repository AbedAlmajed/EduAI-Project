<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e(trans('admin_teacher.List_Teachers')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<?php echo e(trans('admin_teacher.List_Teachers')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                                <a href="<?php echo e(route('Teachers.create')); ?>" class="button" role="button"
                                   aria-pressed="true"><?php echo e(trans('admin_teacher.Add_Teacher')); ?></a><br><br>
                                <div class="table-responsive">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo e(trans('admin_teacher.Name_Teacher')); ?></th>
                                            <th><?php echo e(trans('admin_teacher.Joining_Date')); ?></th>
                                            <th><?php echo e(trans('admin_teacher.Processes')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $i = 0; ?>
                                        <?php $__currentLoopData = $Teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            <?php $i++; ?>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($Teacher->Name); ?></td>
                                            <td><?php echo e($Teacher->Joining_Date); ?></td>
                                            <td>
                                                <div class="dropdown show">
                                                    <a class="button" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <?php echo e(trans('admin_student.Processes')); ?>                                                        </a>
                                                    </a>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                        <a class="dropdown-item" href="<?php echo e(route('Teachers.edit',$Teacher->id)); ?>"><i style="color:green" class="fa fa-edit"></i>&nbsp;    <?php echo e(trans('admin_teacher.edit')); ?> </a>
                                                        <a class="dropdown-item" data-target="#delete_Teacher<?php echo e($Teacher->id); ?>" data-toggle="modal" href="#delete_Teacher<?php echo e($Teacher->id); ?>"><i style="color: red" class="fa fa-trash"></i>&nbsp;  <?php echo e(trans('admin_teacher.Deleted_Teacher')); ?>  </a>
                                                    </div>
                                                </div>
                                            </td>
                                                
                                            </tr>

                                            <div class="modal fade" id="delete_Teacher<?php echo e($Teacher->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <form action="<?php echo e(route('Teachers.destroy','test')); ?>" method="post">
                                                        <?php echo e(method_field('delete')); ?>

                                                        <?php echo e(csrf_field()); ?>

                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title" id="exampleModalLabel"><?php echo e(trans('admin_teacher.Deleted_Teacher')); ?></h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p> <?php echo e(trans('admin_teacher.Deleted_Teacher_tilte')); ?></p>
                                                            <input type="hidden" name="id"  value="<?php echo e($Teacher->id); ?>">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                        data-dismiss="modal"><?php echo e(trans('admin_teacher.Close')); ?></button>
                                                                <button type="submit"
                                                                        class="btn btn-danger"><?php echo e(trans('admin_teacher.Delete')); ?></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </form>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\new mohanned\The final version\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Teachers.blade.php ENDPATH**/ ?>