<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    Lesson
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    Lesson
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
       <div class="card card-statistics h-100">
        <div class="card-body" style="display: flex; flex-wrap: wrap;">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Auth::user()->id === $course->teacher_id): ?>
                    <div class="card" style="width: 18rem; margin-right: 10px; margin-bottom: 10px;">
                        <img class="card-img-top" src="<?php echo e($imag_dir.'/'.$course->time_stamp.$course->title.'/'.$course->images->filename); ?>" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($course->title); ?></h5>
                            <p class="card-text">Description : <?php echo e($course->description); ?></p>
                            <p class="card-text">Year : <?php echo e($course->year_id); ?></p>
                            
                            <p class="card-text">Departments:</p>

                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(in_array($department->id, $course->Department->pluck('id')->toArray())): ?>
                            <ul>

                                    <li><?php echo e($department->Name); ?></li>

                            </ul>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <a class="btn btn-primary" href="<?php echo e(route('lesson.editable',$course->id)); ?>">Go somewhere</a>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\project with quiz test\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/index.blade.php ENDPATH**/ ?>