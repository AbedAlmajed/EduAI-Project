<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
course-overview
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
course-overview
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                data-page-length="50"
                style="text-align: center">
             <thead>
             <tr>
                 <th>#</th>
                 <th>Course Name</th>
                 <th>Students</th>
                 <th>Completion</th>
             </tr>
             </thead>
             <tbody>
             <?php $i = 0; ?>
             <?php $__currentLoopData = $Courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php
    $completedStudentsCount = 0;

    foreach ($Course->students as $student) {
        $studentCourse = DB::table('student_course')
            ->where('student_id', $student->id)
            ->where('course_id', $Course->id)
            ->first();

        $checkedItemsCounter = $studentCourse ? $studentCourse->checked_items_counter : 0;
        $totalItems = $Course->item_counter;

        if ($checkedItemsCounter == $totalItems) {
            $completedStudentsCount++;
        }
    }
?>
                 <tr>
                 <?php $i++; ?>
                 <td><?php echo e($i); ?></td>
                 <td><?php echo e($Course->title); ?></td>
                 <td><?php echo e($Course->students->count()); ?></td>  <!-- Display the count of students enrolled -->
                 <td><?php echo e($completedStudentsCount); ?></td>
                </tr>

               
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </table>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\project with quiz test\start\school-management-system-update_profile_in_dashboard_parent\resources\views/course-overview.blade.php ENDPATH**/ ?>