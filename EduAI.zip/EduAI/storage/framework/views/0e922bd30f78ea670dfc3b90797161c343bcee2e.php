<div class="scrollbar side-menu-bg" style="overflow: scroll">
    <ul class="nav navbar-nav side-menu" id="sidebarnav">
        <!-- menu item Dashboard-->
        <li>
            <a href="<?php echo e(url('/teacher/dashboard')); ?>">
                <div class="pull-left"><i class="ti-home"></i><span
                        class="right-nav-text"><?php echo e(trans('teacher_page.Dashboard')); ?></span>
                </div>
                <div class="clearfix"></div>
            </a>
        </li>
        <!-- menu title -->
        <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title"><?php echo e(trans('teacher_page.EduAi')); ?> </li>

        <!-- الملف الشخصي-->
        <li>
            <a href="<?php echo e(route('profile.show')); ?>"><i class="fas fa-id-card-alt"></i><span
                    class="right-nav-text"> <?php echo e(trans('teacher_page.profile')); ?> </span></a>
        </li>

        
        <!--كورسات-->
        

          <!--الدروس-->
          

          <!-- students-->
          <li>
            <a href="javascript:void(0);" data-toggle="collapse" data-target="#students-menu"><i class="fas fa-user-graduate"></i><?php echo e(trans('teacher_page.Courses')); ?><div class="pull-right"><i class="ti-plus"></i></div><div class="clearfix"></div></a>
            <ul id="students-menu" class="collapse">
                <li> <a href="<?php echo e(route('chat.index')); ?>"> ChatGPT </a></li>
                <li>
                    <a href="javascript:void(0);" data-toggle="collapse" data-target="#Student_information"> <?php echo e(trans('teacher_page.Courses_Information')); ?><div class="pull-right"><i class="ti-plus"></i></div><div class="clearfix"></div></a>
                    <ul id="Student_information" class="collapse">
                        <li> <a href="<?php echo e(route('lesson.index')); ?>">  <?php echo e(trans('teacher_page.Course List')); ?>   </a></li>
                        <li> <a href="<?php echo e(route('courses.index')); ?>"> <?php echo e(trans('teacher_page.Add New Course')); ?> </a></li>
                       
                    </ul>
                </li>
            </ul>
        </li>


    </ul>
</div>
<?php /**PATH C:\Users\moham\Downloads\school-management-system-update_profile_in_dashboard_parent\school-management-system-update_profile_in_dashboard_parent\resources\views/layouts/main-sidebar/teacher-main-sidebar.blade.php ENDPATH**/ ?>