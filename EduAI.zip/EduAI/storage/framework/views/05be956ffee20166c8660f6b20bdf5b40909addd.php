<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    Courses List
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
Courses List

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="title d-flex justify-content-between">
     <h3 class="page-title">Course</h3>

     <p >
         <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-success">Add New</a>

     </p>

</div>



 <div class="card">
     <div class="card-header">
         Course
     </div>

     <div class="card-body">
         <div class="table-responsive">
             <table class="table table-bordered table-striped table-hover datatable datatable-Location">
                 <thead>
                     <tr>
                         <th>
                             Title
                         </th>

                         <th>
                             Description
                         </th>

                         <th>
                             Course Image

                         </th>

                         <th>
                             Published
                         </th>
                         <th>
                             Action
                         </th>
                     </tr>
                 </thead>
                 <tbody>
                 <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if(Auth::user()->id === $course->teacher_id): ?>
                    <?php echo e($counter++); ?>

                     <tr data-entry-id="<?php echo e($course->id); ?>">
                         <td>
                             <?php echo e($course->title ?? ''); ?>

                         </td>

                         <td>
                             <?php echo e($course->description ?? ''); ?>

                         </td>

                         <td>
                             <img width="150" src="<?php echo e($imag_dir . '/' .$course->time_stamp .$course->title . '/' . $course->images->filename); ?>" alt="Course Image">
                         </td>

                         <td>
                             <?php echo e($course->published); ?>

                         </td>
                         <td>
                            <a class="btn btn-xs btn-info" href="<?php echo e(route('courses.edit', $course->id)); ?>">
                                Edit
                            </a>
                            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_Course<?php echo e($course->id); ?>" title="<?php echo e(trans('Grades_trans.Delete')); ?>"><i class="fa fa-trash"></i></button>
                             
                             <div class="modal fade" id="delete_Course<?php echo e($course->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <form action="<?php echo e(route('courses.destroy',$course->id)); ?>" method="post">
                                        <?php echo e(method_field('delete')); ?>

                                        <?php echo e(csrf_field()); ?>

                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title" id="exampleModalLabel"><?php echo e(trans('Teacher_trans.Delete_Teacher')); ?></h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <p> <?php echo e(trans('My_Classes_trans.Warning_Grade')); ?></p>
                                            <input type="hidden" name="id"  value="<?php echo e($course->id); ?>">
                                        </div>
                                        <div class="modal-footer">
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(trans('My_Classes_trans.Close')); ?></button>
                                                <button type="submit"
                                                        class="btn btn-danger"><?php echo e(trans('My_Classes_trans.submit')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                         </td>
                     </tr>
                     <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php if($counter==0): ?>
                     <tr>
                         <td class="text-center" colspan="10">Not found !</td>
                     </tr>
                     <?php endif; ?>
                 </tbody>
             </table>
         </div>


     </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Project Backup\mohanned\school-management-system-update_profile_in_dashboard_parent (2)\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/courses/index.blade.php ENDPATH**/ ?>