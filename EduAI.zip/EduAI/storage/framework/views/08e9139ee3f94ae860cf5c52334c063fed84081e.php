<div class="scrollbar side-menu-bg" style="overflow: scroll">
    <ul class="nav navbar-nav side-menu" id="sidebarnav">
        <!-- menu item Dashboard-->
        <li>
            <a href="<?php echo e(url('/teacher/dashboard')); ?>">
                <div class="pull-left"><i class="ti-home"></i><span
                        class="right-nav-text"><?php echo e(trans('main_trans.Dashboard')); ?></span>
                </div>
                <div class="clearfix"></div>
            </a>
        </li>
        <!-- menu title -->
        <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title"><?php echo e(trans('main_trans.Programname')); ?> </li>

        <!-- الملف الشخصي-->
        <li>
            <a href="<?php echo e(route('profile.show')); ?>"><i class="fas fa-id-card-alt"></i><span
                    class="right-nav-text">الملف الشخصي</span></a>
        </li>

        
        <!--كورسات-->
        <li>
            <a href="<?php echo e(route('courses.index')); ?>"><i class="fas fa-id-card-alt"></i><span
                    class="right-nav-text"> كورسات</span></a>
        </li>

          <!--الدروس-->
          <li>
            <a href="<?php echo e(route('lesson.index')); ?>"><i class="fas fa-id-card-alt"></i><span
                    class="right-nav-text"> الدروس</span></a>
        </li>


    </ul>
</div>
<?php /**PATH C:\Users\user\Desktop\Project\New Version\school-management-system-update_profile_in_dashboard_parent\school-management-system-update_profile_in_dashboard_parent\resources\views/layouts/main-sidebar/teacher-main-sidebar.blade.php ENDPATH**/ ?>