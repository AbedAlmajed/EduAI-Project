<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Laravel 10 Summernote Text Editor </title>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
</head>
<body>
<div class="container p-4 ">
    <div class="row justify-content-md-center">
        <div class="col-md-12">
            <div class="text-center">
                <h1 class="">Laravel 10 Summernote Text Editor </h1>
            </div> 
            <form action="<?php echo e(route('WYSIWYG.store',$id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label for="">Title:</label>
                <input type="text" class="form-control" name="title">
                <label for="">Description:</label>
                <textarea name="description" id="description" cols="30" rows="10"></textarea>
                <div class="col-md-5">
                    <div class="form-group text-center ">
                        <label for="sections"><?php echo e(__('Sections')); ?> :<span class="text-danger">*</span></label>
                        <select class="custom-select mr-sm-2" name="section_id"  >
                            <option selected disabled><?php echo e(trans('Parent_trans.Choose')); ?>...</option>
                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($section->course_id == $id): ?>
                                <option  value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php $__errorArgs = ['sections'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-lg btn-primary">Submit</button>
            </form>
            <form action="<?php echo e(route('lesson.editable',$id)); ?>" method="get">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-lg btn-primary">Cancel</button>
            </form>
        </div>
    </div>
</div>
<script>
    $('#description').summernote({
        placeholder: 'description...',
        tabsize:2,
        height:300
    });
</script>
</body>
</html><?php /**PATH C:\Users\user\Desktop\project with quiz test\mohanned\school-management-system-update_profile_in_dashboard_parent\resources\views/pages/Teachers/Lesson/WYSIWYG/create.blade.php ENDPATH**/ ?>