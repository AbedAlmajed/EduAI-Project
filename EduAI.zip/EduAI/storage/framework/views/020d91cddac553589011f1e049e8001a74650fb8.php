<!-- Footer opened -->
<footer class="bg-white p-4">
   <div class="row">
       <div class="col-md-6">
           <div class="text-center text-md-left">
               <p class="mb-0"> &copy; <?php echo e(trans('main_trans.Copyright')); ?> <span id="copyright">
                       <script>
                           document.getElementById('copyright').appendChild(document
                               .createTextNode(new Date().getFullYear()))
                       </script>
                   </span>. <a href="#"> </a><?php echo e(trans('main_trans.Name_Programer')); ?></p>
           </div>
       </div>
   </div>
</footer>
<!-- Footer closed -->
<?php /**PATH C:\Users\user\Desktop\mohannad\test1\school-management-system-update_profile_in_dashboard_parent\resources\views/layouts/footer.blade.php ENDPATH**/ ?>