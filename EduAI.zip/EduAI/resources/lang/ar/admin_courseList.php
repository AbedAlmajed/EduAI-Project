<?php

return [
'Course-List' => 'قائمة الكورسات',
'Course Name' => 'اسم الكورس',
'Department(s)' => 'القسم (الأقسام)',
'Process' => 'عملية',
'DeleteCourse' => 'حذف الكورس',
'publish' => 'منشور',
'unpublish' => 'غير منشور',
'Delete' => 'حذف الكورس',
'Cancel' => 'إلغاء',
'Delete' => 'حذف',
'title' => 'هل أنت متأكد أنك تريد حذف هذه الكورس؟',
'Published'=>'إظهار',
'Unpublished'=>'إخفاء',
];