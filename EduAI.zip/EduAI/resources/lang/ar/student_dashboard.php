<?php

return [

    'welcome' => 'مرحبا بك ',
    'EduAi' => 'EduAi',




];