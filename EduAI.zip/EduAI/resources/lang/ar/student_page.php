<?php

return [

 
    'Dashboard' => 'لوحة التحكم',
    'EduAi' => 'EduAi',
    'profile' => 'الملف الشخصي',
    'Courses List' => 'قائمة الكورسات',
    'My Courses' => 'كورساتي',
    'Courses' => 'الكورسات',
    'Finished Courses List' => 'قائمة الكورسات المنتهية',
    'List_Teachers' => 'قائمة المدرّسين',
    'Course List' => 'قائمة الكورسات',
    'Progress Courses List' => 'قائمة الكورسات قيد التقدم',

];