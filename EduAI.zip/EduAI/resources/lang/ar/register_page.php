<?php

return [

   
    'Student Register'=>'انشاء حساب طالب',
    'Register' => ' انشاء حساب ',
    'Name' => 'الاسم باللغة الإنجليزية',
    'Arabic Name' => 'الاسم باللغة العربية',
    'E-Mail Address' => 'عنوان البريد الإلكتروني',
    'Department' => 'القسم',
    'Years' => 'السنة',
    'Password' => 'كلمة المرور',
    'Confirm Password' => 'تأكيد كلمة المرور',
    'Have an account? Login' => 'لديك حساب؟ تسجيل الدخول',

];