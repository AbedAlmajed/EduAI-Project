<?php

return [
    'course-overview' => 'نظرة عامة على الكورس',
'Course Name' => 'اسم الكورس',
'Students' => 'الطلاب',
'Completion' => 'الطلاب الذين أكملوا الدورة',
];