<?php

return [
    'Name_Teacher'=>'اسم المدرّس',
    'Add_Teacher'=>'اضافة مدرّس',
    'Edit_Teacher'=>'تعديل مدرّس',
    'Email'=>'البريد الالكتروني',
    'Password'=>'كلمة المرور',
    'Name_ar'=>'اسم المدرّس باللغة العربية',
    'Name_en'=>'اسم المدرّس باللغة الانجليزية',
    'Joining_Date'=>'تاريخ التعين',
    'List_Teachers'=>'قائمة المدرّسين ',
    'Delete'=>'حذف',
    'Teacher_details' => 'تفاصيل المدرّس',
    'Deleted_Teacher' => 'حذف بيانات المدرّس',
    'Deleted_Teacher_tilte' => 'هل انت متاكد من حذف المدرّس ؟',
    'Close'=>'اغلاق',
    'Address'=>'العنوان',
    'add'=>'تحديث بيانات المدرّس',
    'Logout'=>'تسجيل خروج',
    'edit'=>'تعديل بيانات المدرّس',

];