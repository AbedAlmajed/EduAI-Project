<?php

return [

   

    'profile' => 'الملف الشخصي',
    'admin' => 'ادمن',
    'Admin name in Arabic' => 'اسم الادمن باللغة العربية',
    'Admin name in English' => 'اسم الادمن باللغة الإنجليزية',
    'password' => 'كلمة المرور',
    'Show password' => 'إظهار كلمة المرور',
    'Data Edit' => 'تحديث البيانات',

];