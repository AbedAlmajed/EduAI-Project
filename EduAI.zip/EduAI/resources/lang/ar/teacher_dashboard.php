<?php

return [

    'EduAi' => 'EduAi',
    'welcome' => 'مرحبا بك',
    'Latest on system operations' => 'آخر ما تم في عمليات النظام',
    'Instructor' => 'المدرّسين',
    'Instructor Name' => 'اسم المدرّس',
    'Date of hiring' => 'تاريخ التعيين',
    'Date added' => 'تاريخ الإضافة',
    'data' => 'لا توجد بيانات',
    'test'=>'تجربة',
    'welcome2'=>'مرحباً أيها المدرّس! هل تحتاج إلى المساعدة أو لديك أي أسئلة؟ انقر',
    'here'=>'هنا',
    'chat'=>'للدردشة مع chatbot المفيد لدينا',
    
];