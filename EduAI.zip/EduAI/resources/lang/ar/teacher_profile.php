<?php

return [
    'profile' => 'الملف الشخصي',
    'teacher' => 'المدرّس',
    'teacher name english'=>'اسم المدرّس بالإنجليزية',
    'teacher name arabic'=>'اسم المدرّس بالعربية',
    'department'=>'القسم',
    'year'=>'السنة',
    'password'=>'كلمة المرور',
    'show password'=>'إظهار كلمة المرور',
    'Edit Data'=>'تحديث البيانات',
    

];