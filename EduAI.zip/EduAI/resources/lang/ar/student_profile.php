<?php

return [

    'profile' => 'الملف الشخصي',
    'student' => 'الطالب',
    'student name english'=>'اسم الطالب بالإنجليزية',
    'student name arabic'=>'اسم الطالب بالعربية',
    'department'=>'القسم',
    'year'=>'السنة',
    'password'=>'كلمة المرور',
    'show password'=>'إظهار كلمة المرور',
    'Edit Data'=>'تحديث البيانات',
    




];