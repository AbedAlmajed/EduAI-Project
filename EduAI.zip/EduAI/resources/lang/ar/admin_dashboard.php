<?php

return [
    'Dashboard' => 'لوحة التحكم',
    'Number Of Student' => 'عدد الطلاب',
    'Number Of Instructor' => 'عدد المدرّسين',
    'Data Display' => 'عرض البيانات',
    'Latest processes on the system' => 'أحدث العمليات على النظام',
    'Student' => 'طالب',
    'Instructor' => 'مدرّس',
    'Student Name' => 'اسم الطالب',
    'Student Email' => 'بريد الطالب الإلكتروني',
    'Date added' => 'تاريخ الإضافة',
    'Instructor Name' => 'اسم المدرّس',
    'Date of hiring' => 'تاريخ التوظيف',
    
    
    
    
    
    
];