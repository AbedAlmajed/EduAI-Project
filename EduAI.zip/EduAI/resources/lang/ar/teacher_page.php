<?php

return [

   

    'Dashboard' => 'لوحة التحكم',
    'EduAi' => 'EduAi',
    'profile' => 'الملف الشخصي',
    'Courses List' => 'قائمة الكورسات',
    'My Courses' => 'كورساتي',
    'Courses_Information' => 'معلومات الكورسات',
    'Courses' => 'الكورسات',
    'Course List' => 'قائمة الكورسات',
    'Add New Course' => 'إضافة كورس جديد',

];