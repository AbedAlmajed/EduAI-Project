<?php

return [

   
    'Dashboard' => 'لوحة التحكم',
    'EduAi' => 'EduAi',
    'profile' => 'الملف الشخصي',
    'Student' => 'طالب',
    'Student_information' => 'معلومات الطالب',
    'add_student' => 'إضافة طالب',
    'list_students' => 'قائمة الطلاب',
    'Teachers' => 'المدرّسين',
    'List_Teachers' => 'قائمة المدرّسين',
    'Course List' => 'قائمة الكورسات',
    'Course Overview' => 'نظرة عامة على الكورس',

];