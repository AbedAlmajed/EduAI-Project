<?php

return [
    'EduAi'=>'EduAi',
    'Copyright'=>'جميع الحقوق محفوظة',

];