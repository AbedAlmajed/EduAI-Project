<?php

return [

    'add_student' => 'إضافة طالب',
    'personal_information' => 'المعلومات الشخصية',
    'department' => 'القسم',
    'year' => 'السنة',
    'Add' => 'إضافة',
    'name_ar' => 'اسم الطالب بالعربية',
    'name_en' => 'اسم الطالب بالإنجليزية',
    'name'=>'اسم الطالب',
    'email' => 'البريد الإلكتروني',
    'password' => 'كلمة المرور',
    'list_students' => 'قائمة الطلاب',
    'Processes' => 'عمليات',
    'view Data' => 'عرض بيانات الطالب',
    'Edit Data' => 'تعديل بيانات الطالب',
    'Delete Data' => 'حذف بيانات الطالب',
    'Student_Edit' => 'تعديل الطالب',
    'Student_details' => 'تفاصيل الطالب',
    'Deleted_Student' => 'حذف بيانات الطالب',
    'Deleted_Student_tilte' => 'هل أنت متأكد من حذف الطالب؟',
    'Close' => 'إغلاق',
    'Delete' => 'حذف',
    'submit'=>'تحديث البيانات',

];