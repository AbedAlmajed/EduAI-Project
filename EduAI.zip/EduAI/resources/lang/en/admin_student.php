<?php

return [

    
    'add_student'=>'Add Student',
    'personal_information' => 'Personal information',
    'department'=>'Department',
    'year'=>'Year',
    'submit'=>'Update',
    'name_ar' => 'Student name in Arabic',
    'name_en' => 'Student name in English',
    'name'=>'Name',
    'email' => 'Email',
    'password' => 'Password',
    'list_students'=>'Student List ',
    'Processes' => 'Processes',
    'view Data'=>'view  Student Data',
    'Edit Data'=>'Edit Student Data',
    'Delete Data'=>'Delete Student Data',
    'Student_Edit'=>'Edit Student',
    'Student_details' => 'Student Details',
    'Deleted_Student' => 'Delete student data',
    'Deleted_Student_tilte' => 'Are you sure to delete the student ?',
    'Close'=>'Close',
    'Delete'=>'Delete',


];