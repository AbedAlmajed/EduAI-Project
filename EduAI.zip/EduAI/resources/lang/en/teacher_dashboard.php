<?php

return [

    'EduAi' => 'EduAi',
    'welcome' => 'Welcome',
    'Latest on system operations'=>'Latest on system operations',
    'Instructor'=>'Instructor',
    'Instructor Name'=>'Instructor Name',
    'Date of hiring'=>'Date of hiring',
    'Date added'=>'Date added',
    'data'=>'There is no data',
   'welcome2'=>'Welcome, Instructor! Need assistance or have any questions? Click',
'here'=>'here',
'chat'=>'to chat with our helpful chatbot',



];