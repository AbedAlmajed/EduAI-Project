<?php

return [
    'Course-List'=>'Courses List',
    'Course Name'=>' Course Name',
    'Department(s)'=>' Department(s)',
    'Process'=>'Process',
    'DeleteCourse'=>'Delete Course',
    'publish'=>'published',
    'unpublish'=>'unpublished',
    'Cancel'=>'Cancel',
    'Delete'=>'Delete',
    'title'=>'Are you sure you want to delete this course?',
'Published'=>'Published',
'Unpublished'=>'Unpublished',
];