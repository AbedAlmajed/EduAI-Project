<?php

return [

   

    'Dashboard' => 'Dashboard',
    'EduAi' => 'EduAi',
    'profile'=>'profile',
    'Student'=>'Student',
    'Student_information'=>'Student Information',
    'add_student'=>'Add Student',
    'list_students'=>'Students List',
    'Teachers'=>'Instructors', 
    'List_Teachers'=>'Instructors List',
    'Course List'=>'Course List',
    'Course Overview'=>'Course Overview',

];