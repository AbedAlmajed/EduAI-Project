<?php

return [

   

    'Dashboard' => 'Dashboard',
    'EduAi' => 'EduAi',
    'profile'=>'profile',
    'Courses List'=>'Courses List',
    'My Courses'=>'My Courses',
    'Courses_Information'=>'Courses_Information',
    'Courses'=>'Courses',
    'List_Teachers'=>'Instructor List',
    'Course List'=>'Course List',
    'Add New Course'=>'Add New Course',
    'Add_Teacher'=>'Add Instructor',

];