<?php

return [
    'Dashboard'=>'Dashboard',
    'Number Of Student'=>'Number Of Student',
    'Number Of Instructor'=>'Number Of Instructor',
    'Data Display'=>'Data Display',
    'Latest processes on the system'=>'Latest processes on the system',
    'Student'=>'Student',
    'Instructor'=>'Instructor',
    'Student Name'=>'Student Name',
    'Student Email'=>'Student Email',
    'Date added'=>'Date added',
    'Instructor Name'=>'Student Name',
    'Date added'=>'Date added',
    'Date of hiring'=>'Date of hiring',

];