<?php

return [
    'course-overview'=>'Course Overview',
    'Course Name'=>' Course Name',
    'Students'=>'Students',
    'Completion'=>'Students who completed the course',
   

];