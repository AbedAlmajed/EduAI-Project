<?php

return [

    'profile' => 'Profile',
    'teacher' => 'Instructor',
    'teacher name english'=>'Instructor Name In English',
    'teacher name arabic'=>'Instructor Name In Arabic',
    'department'=>'Department',
    'year'=>'Year',
    'password'=>'Password',
    'show password'=>'Show Password',
    'Edit Data'=>'Update',

];