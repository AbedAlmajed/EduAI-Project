<?php

return [

    'welcome' => 'Welcome',
    'EduAi' => 'EduAi',




];