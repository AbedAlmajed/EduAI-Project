<?php

return [

   

    'profile' => 'profile',
    'admin' => 'admin',
    'profile'=>'profile',
    'Admin name in Arabic'=>'Admin name in Arabic',
    'Admin name in English'=>'Admin name in English',
    'password'=>'password',
    'Show password'=>'Show password',
    'Data Edit'=>'Update', 

];