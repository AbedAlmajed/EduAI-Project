<?php

return [

   

    'Dashboard' => 'Dashboard',
    'EduAi' => 'EduAi',
    'profile'=>'profile',
    'Courses List'=>'Courses List',
    'My Courses'=>'My Courses',
    'Courses'=>'Courses',
    'Finished Courses List'=>'Finished Courses List', 
    'List_Teachers'=>'List_Teachers',
    'Course List'=>'Course List',
    'Progress Courses List'=>'Progress Courses List',

];