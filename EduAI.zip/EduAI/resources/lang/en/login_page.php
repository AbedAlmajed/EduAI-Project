<?php

return [
    'EduAi'=>'EduAi',
    'Student'=>'Student Login',
    'Instructor'=>'Instructor Login',
    'Admin'=>'Admin Login',
    'Email'=>'Email',
    'password'=>'Password',
    'Dont have an account?'=>'Dont have an account?',
    'Register here'=>'Register here',
    'Login'=>'Login',
    'RememberMe'=>'Remember Me',
    'Forgot Your Password'=>'Reset Your Password؟',
    'Privacy Policy'=>'Privacy Policy',
    'Terms of Use'=>'Terms of Use',
    'content'=>'An educational project with the addition of AI tools to address individual differences between students. With AI assistance, students can tackle their own questions more effectively.',
    'Welcome'=>'Welcome',
    'To'=>'To',
    'email'=>'Email Not Found',
    'password2'=>'invalid password',
];