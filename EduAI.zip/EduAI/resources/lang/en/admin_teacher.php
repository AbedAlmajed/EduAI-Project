<?php

return [
    'Name_Teacher'=>'Name Instructor',
    'Add_Teacher'=>'Add Instructor',
    'Edit_Teacher'=>'Edit Instructor',
    'Email'=>'Email',
    'Password'=>'Password',
    'Name_ar'=>'Name_ar',
    'Name_en'=>'Name_en',
    'Joining_Date'=>'Joining_Date',
    'Processes'=>'Processes',
    'List_Teachers'=>'Instructor List ',
    'Delete'=>'Delete',
    'Teacher_details' => 'Instructor Details',
    'Deleted_Teacher' => 'Delete Instructor data',
    'Deleted_Teacher_tilte' => 'Are you sure to delete the Instructor ?',
    'Close'=>'Close',
    'Address'=>'Address',
    'add'=>'Add',
    'Logout'=>'Logout',
    'edit'=>'Edit Instructor data',
];