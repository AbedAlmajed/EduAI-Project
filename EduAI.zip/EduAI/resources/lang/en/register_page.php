<?php

return [

   
     'Student Register'=>'Student Register',
    'Register' => 'Register',
    'Name' => 'English Name',
    'Arabic Name'=>'Arabic Name',
    'E-Mail Address'=>'Email Address',
    'Department'=>'Department',
    'Years'=>'Years',
    'Password'=>'Password',
    'Confirm Password'=>'Confirm Password', 
    'Have an account? Login'=>'Have an account? Login',

];