<?php

return [
    'EduAi'=>'EduAi',
    'Copyright'=>'Copyright',

];