<?php

return [

    'profile' => 'Profile',
    'student' => 'Student',
    'student name english'=>'Student Name In English',
    'student name arabic'=>'Student Name In Arabic',
    'department'=>'Department',
    'year'=>'Year',
    'password'=>'Password',
    'show password'=>'Show Password',
    'Edit Data'=>'Update',




];